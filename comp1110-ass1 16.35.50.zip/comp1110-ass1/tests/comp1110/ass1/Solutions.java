package comp1110.ass1;

public class Solutions {

}
